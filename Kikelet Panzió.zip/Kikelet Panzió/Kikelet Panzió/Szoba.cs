﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikelet_Panzió
{
    internal class Szoba
    {
        string szobaszám;
        int férőhely;
        int ár;

        public Szoba(string szobaszám, int férőhely, int ár)
        {
            this.szobaszám = szobaszám;
            this.férőhely = férőhely;
            this.ár = ár;
        }

        public string Szobaszám { get => szobaszám; set => szobaszám = value; }
        public int Férőhely { get => férőhely; set => férőhely = value; }
        public int Ár { get => ár; set => ár = value; }

        public override string ToString()
        {
            return $"{szobaszám};{férőhely};{ár}";
        }
    }
}
