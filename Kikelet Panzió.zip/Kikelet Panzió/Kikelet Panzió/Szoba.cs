﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikelet_Panzió
{
    public class Szoba
    {
        string szobaszám;
        int férőhely;
        int ár;
        bool egyedül;

        public Szoba(string szobaszám, int férőhely, int ár, bool egyedül)
        {
            this.szobaszám = szobaszám;
            this.férőhely = férőhely;
            this.ár = ár;
            this.egyedül = egyedül;
        }

        public string Szobaszám { get => szobaszám; set => szobaszám = value; }
        public int Férőhely { get => férőhely; set => férőhely = value; }
        public int Ár { get => ár; set => ár = value; }
        public bool Egyedül { get => egyedül; set => egyedül = value; }

        public override string ToString()
        {
            return $"{szobaszám};{férőhely};{ár};{egyedül}";
        }
    }
}
