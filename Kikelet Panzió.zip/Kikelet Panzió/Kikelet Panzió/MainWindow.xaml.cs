﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kikelet_Panzió
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<Emberek> emberekk = new List<Emberek>();
        public MainWindow()
        {
            InitializeComponent();
           
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (cbxmeglévő.IsChecked == true)
            {
                foreach (Emberek item in emberekk)
                {
                    MessageBox.Show(item.ToString());
                }
                szobafoglalás foglaló = new szobafoglalás();
                foglaló.ShowDialog();
            }
            else if (cbxmeglévő.IsChecked == false)
            {
                emberekk.Add(new Emberek(tbxid.Text, tbxnév.Text, DateTime.Parse(dprdátum.Text), tbxemail.Text, cbxvip.IsChecked == true));
                foreach (Emberek item in emberekk)
                {
                    MessageBox.Show(item.ToString());
                }
                szobafoglalás foglaló = new szobafoglalás();
                foglaló.ShowDialog();
            }
        }

        private void dprdátum_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            string[] név = dprdátum.Text.Split('.');
            tbxid.Text = tbxnév.Text + név[0];
        }

        private void tbxnév_TextChanged(object sender, TextChangedEventArgs e)
        {
            string[] név = dprdátum.Text.Split('.');
            tbxid.Text = tbxnév.Text + név[0];
        }

        private void cbxmeglévő_Checked(object sender, RoutedEventArgs e)
        {
            if (cbxmeglévő.IsChecked==true)
            {
                tbxid.IsReadOnly = false;
                tbxnév.IsEnabled = false;
                tbxemail.IsEnabled = false;
                dprdátum.IsEnabled = false;
                cbxvip.IsEnabled = false;
            }
        }

        private void tbxid_TextChanged(object sender, TextChangedEventArgs e)
        {
            foreach (var item in emberekk)
            {
                if (tbxid.Text==item.Id)
                {
                    
                    tbxnév.Text = item.Név;
                    tbxemail.Text = item.Email;
                    dprdátum.Text =  item.Születési.ToString();
                    cbxvip.IsChecked = item.VIP;
                    tbxid.Text = item.Id;
                }
            }
            
        }

        private void cbxmeglévő_Unchecked(object sender, RoutedEventArgs e)
        {
            if (cbxmeglévő.IsChecked == false)
            {
                tbxid.IsReadOnly = true;
                tbxnév.IsEnabled = true;
                tbxemail.IsEnabled = true;
                dprdátum.IsEnabled = true;
                cbxvip.IsEnabled = true;
            }
        }
    }
}
