﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikelet_Panzió
{
    /// <summary>
    /// Interaction logic for szobafoglalás.xaml
    /// </summary>
    public partial class szobafoglalás : Window
    {
        public static List<Szoba> szobák=new List<Szoba>();
        public szobafoglalás()
        {
            
            InitializeComponent();
            for (int i = 1; i < 7; i++)
            {
               cbxszobaszám.ItemsSource += i.ToString();
            }
            for (int i = 2; i < 5; i++)
            {
                cbxágyak.ItemsSource += i.ToString();
            }

        }

        private void btnvissza_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.emberekk.RemoveAt(MainWindow.emberekk.Count-1);
            Close();
        }

        private void btnfoglalás_Click(object sender, RoutedEventArgs e)
        {
            szobák.Add(new Szoba(cbxszobaszám.Text,int.Parse(cbxágyak.Text),int.Parse(tbxár.Text), cbxegyedül.IsChecked==true));
            foreach (Szoba item in szobák)
            {
                MessageBox.Show(item.ToString());
            }
        }

        private void cbxágyak_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbxegyedül.IsChecked==true)
            {
                tbxár.Text = "12000";
            }
            else {
                if (cbxágyak.SelectedIndex == 0)
                {
                    tbxár.Text = "20000";
                }
                else if (cbxágyak.SelectedIndex == 1)
                {
                    tbxár.Text = "30000";
                }
                else if (cbxágyak.SelectedIndex == 2)
                {
                    tbxár.Text = "40000";
                }
            }
        }

        private void cbxegyedül_Checked(object sender, RoutedEventArgs e)
        {
            if (cbxegyedül.IsChecked == true)
            {
                tbxár.Text = "12000";
            }
            
        }

        private void cbxegyedül_Unchecked(object sender, RoutedEventArgs e)
        {
            if (cbxegyedül.IsChecked == false)
            {
                if (cbxágyak.SelectedIndex == 0)
                {
                    tbxár.Text = "20000";
                }
                else if (cbxágyak.SelectedIndex == 1)
                {
                    tbxár.Text = "30000";
                }
                else if (cbxágyak.SelectedIndex == 2)
                {
                    tbxár.Text = "40000";
                }
            }
        }
    }
}
