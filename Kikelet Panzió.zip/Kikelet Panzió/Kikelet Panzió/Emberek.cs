﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikelet_Panzió
{
    internal class Emberek
    {
        string id;
        string név;
        TimeSpan születési;
        string email;
        bool vIP;

        public Emberek(string id, string név, TimeSpan születési, string email, bool vIP)
        {
            this.id = id;
            this.név = név;
            this.születési = születési;
            this.email = email;
            this.vIP = vIP;
        }

        public string Id { get => id; set => id = value; }
        public string Név { get => név; set => név = value; }
        public TimeSpan Születési { get => születési; set => születési = value; }
        public string Email { get => email; set => email = value; }
        public bool VIP { get => vIP; set => vIP = value; }

        public override string ToString()
        {
            return $"{id};{név};{születési};{email};{vIP}";
        }
    }
}
