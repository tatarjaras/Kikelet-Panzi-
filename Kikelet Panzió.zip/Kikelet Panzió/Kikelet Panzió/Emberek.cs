﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikelet_Panzió
{
    public class Emberek
    {
        string id;
        string név;
        DateTime születési;
        string email;
        bool vIP;

        public Emberek(string id, string név, DateTime születési, string email, bool vIP)
        {
            this.id = id;
            this.név = név;
            this.születési = születési;
            this.email = email;
            this.vIP = vIP;
        }

        public string Id { get => id; set => id = value; }
        public string Név { get => név; set => név = value; }
        public DateTime Születési { get => születési; set => születési = value; }
        public string Email { get => email; set => email = value; }
        public bool VIP { get => vIP; set => vIP = value; }

        public override string ToString()
        {
            return $"{id};{név};{születési.Year}:{születési.Month}:{születési.Day};{email};{vIP}";
        }
    }
}
